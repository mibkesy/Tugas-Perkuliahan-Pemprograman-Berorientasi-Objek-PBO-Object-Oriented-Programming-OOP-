
import javax.swing.JButton;
import javax.swing.JFrame;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author M. Irfan Baari
 */
public class Window_Swing {
    /*import javax.swing.*;*/
   class gui{
       //<editor-fold defaultstate="collapsed" desc="comment">
       //<editor-fold defaultstate="collapsed" desc="comment">
       //<editor-fold defaultstate="collapsed" desc="comment">
       /* public static void main(String args[]){*/
//</editor-fold>
//</editor-fold>
//</editor-fold>
        JFrame frame = new JFrame("My First GUI");
        /*frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);*/
        /*frame.setSize(300,300);*/
       JButton button1 = new JButton("Press");
       /*frame.getContentPane().add(button1);*/
       /* frame.setVisible(true);*/
     }
}
    
/*}*/