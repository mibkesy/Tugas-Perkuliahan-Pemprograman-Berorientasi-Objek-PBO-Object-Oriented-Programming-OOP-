package id.itech.mod1;

public class BaseHello {
    public static void main(String args[]){
        System.out.println("Hello Me");
    }
}
